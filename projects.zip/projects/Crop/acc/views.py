import pandas as pd
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth

# Create your views here.

def register(request):
	if request.method == 'POST':
		first_name = request.POST['first_name']
		last_name = request.POST['last_name']
		username = request.POST['username']
		email = request.POST['email']
		password1 = request.POST['password1']
		password2 = request.POST['password2']

		if password1==password2:
			if User.objects.filter(username=username).exists():
				messages.info(request,'Username taken..')
				return redirect('register')
			elif User.objects.filter(email=email).exists():	
				messages.info(request,'Email taken..')
				return redirect('register')
			else:
				user = User.objects.create_user(username=username,first_name=first_name,last_name=last_name,password=password1,email=email)
				user.save();
				print('User created..')
				return redirect('login')
		else:
			messages.info(request,'Password not matching..')
			return redirect('register')
		return redirect('/')
	else:
		return render(request,'register.html')


def login(request):
	if request.method== 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = auth.authenticate(username=username,password=password)
		if user is not None:
			auth.login(request,user)
			return redirect('/')
		else:
			messages.info(request,'invalid credentials')
			return redirect('login')
	else:
		return render(request,'login.html')

def form(request):
	if request.method== 'POST':
		Area = request.POST['state']
		Item = request.POST['crop']
		crop_year = request.POST['year']
		rainfall = float(request.POST['rainfall'])
		temperature =float(request.POST['temp'])
		pest =float(request.POST['pest'])
		import pandas as pd
		df=pd.read_csv(r"C:\Users\Lenovo\projects\priya\myapp\static\myapp\dataset\yield_df.csv")
		cnames=df.Area.unique()
		Items=df.Item.unique()
		df=df.drop(['srno.','Year'],axis=1)
		y=df['hg/ha_yield']
		x=df.drop(['hg/ha_yield'],axis=1)
		import numpy as np
		from sklearn.model_selection import train_test_split
		from sklearn.preprocessing import LabelEncoder
		label_encoder = LabelEncoder()
		xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.8,random_state=42)
		xtrain['Area'] = label_encoder.fit_transform(xtrain['Area'])
		xtrain['Item'] = label_encoder.fit_transform(xtrain['Item'])
		xtest['Area'] = label_encoder.fit_transform(xtest['Area'])
		xtest['Item'] = label_encoder.fit_transform(xtest['Item'])
		cnames1 = label_encoder.fit_transform(cnames)
		Items1 = label_encoder.fit_transform(Items)
		xx,yy={},{}
		for i in range(len(cnames)):
			xx[cnames[i]]=cnames1[i]
		for i in range(len(Items)):
			yy[Items[i]]=Items1[i]
		from sklearn.tree import DecisionTreeRegressor
		regressor = DecisionTreeRegressor()
		regressor.fit(xtrain, ytrain)
		y_pred = regressor.predict(np.asarray([[xx[Area],yy[Item],temperature,pest,rainfall]]))
		df=pd.DataFrame({'Crop:':Item, 'Predicted:':str(y_pred[0])},index=[0])
		return render(request,'predict.html',{'DataFrame': df})
	else:
		return render(request,'form.html')
def logout(request):
	auth.logout(request)
	return redirect('/')


 